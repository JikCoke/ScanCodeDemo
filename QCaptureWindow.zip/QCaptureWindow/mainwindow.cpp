#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QZXing.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    capturing_dialog_ = nullptr;
    manager = new QNetworkAccessManager(this);
}

MainWindow::~MainWindow()
{
    if( capturing_dialog_)
    {
        capturing_dialog_->flag = false;
        capturing_dialog_->close();
        delete capturing_dialog_;
        capturing_dialog_ = nullptr;
    }
    delete ui;
}

void MainWindow::on_showButton_clicked()
{
    if(capturing_dialog_ != nullptr ) {

           capturing_dialog_->show();
       } else {
           capturing_dialog_ = new CapturingDialog(this);
           connect(capturing_dialog_,&CapturingDialog::sendPixmap,this,&MainWindow::receivePixmap);
           capturing_dialog_->show();
       }
}

void MainWindow::receivePixmap(QPixmap pix)
{
    QImage img = pix.toImage();        //加载图像

    ui->label->setPixmap(pix);

    QZXing decoder;
    decoder.setDecoder( QZXing::DecoderFormat_CODE_128 | QZXing::DecoderFormat_QR_CODE);
    QString result = decoder.decodeImage(img);

    if( result != "" && flag)
    {
        flag = false;
        QStringList data = result.split("&ticket=");
        QString ticket = data[data.size()-1];
        QString ret = Request(ticket);
        qDebug() << ticket;

        QString token = ConfirmRequest();
        if( ticket != "")
        {
            SignIn(token,ticket);
        }
    }
}

QString MainWindow::Request(QString ticket)
{

    QUrl url("https://api-sdk.mihoyo.com/hk4e_cn/combo/panda/qrcode/scan");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    QJsonObject json;
    json.insert("app_id", 4);
    json.insert("device", "");
    json.insert("ticket", ticket);
    QJsonDocument doc(json);
    QByteArray data = doc.toJson();
    QNetworkReply *reply = manager->post(request, data);
    while (!reply->isFinished()) {
        qApp->processEvents();
    }
    QByteArray response_data = reply->readAll();
    QJsonDocument response_doc = QJsonDocument::fromJson(response_data);
    QJsonObject response_obj = response_doc.object();
    QString retcode = response_obj.value("retcode").toString();
    return retcode;
}

QString MainWindow::ConfirmRequest()
{
    QNetworkAccessManager *manager = new QNetworkAccessManager();
    QNetworkRequest request;
    request.setUrl(QUrl(QString("https://api-takumi.miyoushe.com/auth/api/getGameToken?uid=%1").arg(uid)));
    request.setRawHeader("DS",ds);
    request.setRawHeader("cookie", cookit);
    request.setRawHeader("x-rpc-client_type", "1");
    request.setRawHeader("x-rpc-app_version", "2.46.1");
    request.setRawHeader("x-rpc-sys_version", "");
    request.setRawHeader("x-rpc-channel", "");
    request.setRawHeader("x-rpc-device_id", "");
    request.setRawHeader("x-rpc-device_fp", "");
    request.setRawHeader("x-rpc-device_name", "");
    request.setRawHeader("x-rpc-device_model", "");
    request.setRawHeader("Referer", " https://app.mihoyo.com");
    QNetworkReply *reply = manager->get(request);
    QEventLoop loop;
    QObject::connect(reply, SIGNAL(finished()), &loop, SLOT(quit()));
    loop.exec();
    QByteArray response_data = reply->readAll();
    qDebug() << "get请求返回数据: " << response_data;
    QString str = response_data;
    QStringList list = str.split("{\"game_token\":\"");
    str = list[list.size()-1];
    list = str.split("\"");
    return list[0];
}

void MainWindow::SignIn(QString token,QString ticket)
{
    QUrl url("https://api-sdk.mihoyo.com/hk4e_cn/combo/panda/qrcode/confirm");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("DS", ds);
    request.setRawHeader("cookie", cookit);
    request.setRawHeader("x-rpc-client_type", "1");
    request.setRawHeader("x-rpc-app_version", "2.46.1");
    request.setRawHeader("x-rpc-sys_version", "");
    request.setRawHeader("x-rpc-channel", "");
    request.setRawHeader("x-rpc-device_id", "");
    request.setRawHeader("x-rpc-device_fp", "");
    request.setRawHeader("x-rpc-device_name", "");
    request.setRawHeader("x-rpc-device_model", "");
    request.setRawHeader("Referer", "https://app.mihoyo.com");

    QJsonObject payload;
    payload.insert("app_id", 4);
    payload.insert("device", "4F2D5F74-EAED-49D6-B5C7-1AC2BE8D493C");
    QJsonObject innerPayload;
    innerPayload.insert("proto", "Account");
    QJsonObject raw;
    raw.insert("uid",uid);
    raw.insert("token",token);
    QString str = QString("{\"uid\":\"%1\",\"token\":\"%2\"}").arg(uid).arg(token);

    innerPayload.insert("raw", str);
    payload.insert("payload", innerPayload);
    payload.insert("ticket", ticket);

    QJsonDocument document(payload);
    QByteArray byte_array = document.toJson(QJsonDocument::Compact);    //类型转换

    QNetworkAccessManager *manager2 = new QNetworkAccessManager(this);

    QNetworkReply *reply = manager2->post(request, byte_array);
    QEventLoop loop;
    connect(manager2,SIGNAL(finished(QNetworkReply*)),&loop,SLOT(quit()));

    QObject::connect(reply, SIGNAL(finished()), &loop, SLOT(quit()));
    loop.exec();
    QString response_data = reply->readAll();
    if( response_data.contains("OK",Qt::CaseSensitive))
    {
        qDebug() << response_data;
        ui->lineEdit->setText("抢码成功");
    }
    else
    {
        ui->lineEdit->setText("抢码失败");
        flag = true;
    }
}
